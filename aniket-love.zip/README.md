# aniket-love
A simple two-slide HTML landing page made as a surprise for Aniket.

**Description:** Happy Boyfriend's Day — a small surprise page from Bhavika to Aniket.

How to use:
1. Upload `aniket-love.html` to GitHub repository.
2. Enable GitHub Pages (Settings → Pages → Branch: main, Folder: / (root)).
3. Your site will be available at: https://<your-username>.github.io/aniket-love/

You can also generate a QR code for the live URL and share it with Aniket.
